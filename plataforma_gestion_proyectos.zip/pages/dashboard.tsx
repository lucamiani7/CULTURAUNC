import { useState } from "react";

export default function Dashboard() {
  const [projects, setProjects] = useState([
    { id: 1, name: "Evento Corporativo", processes: ["Producción", "Comunicación"] },
    { id: 2, name: "Festival Primavera", processes: ["Producción"] },
  ]);

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold mb-4">Proyectos</h1>
      <ul className="space-y-3">
        {projects.map((p) => (
          <li key={p.id} className="p-4 border rounded bg-white shadow">
            <h2 className="text-xl font-semibold">{p.name}</h2>
            <p className="text-sm text-gray-600">Procesos: {p.processes.join(", ")}</p>
          </li>
        ))}
      </ul>
      <button
        className="mt-6 bg-green-600 text-white px-4 py-2 rounded"
        onClick={() => alert("Función para crear proyecto próximamente")}
      >
        + Crear nuevo proyecto
      </button>
    </main>
  );
}