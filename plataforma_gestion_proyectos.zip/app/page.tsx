import Link from "next/link";

export default function Home() {
  return (
    <main className="p-8 text-center">
      <h1 className="text-4xl font-bold mb-4">Gestión de Proyectos</h1>
      <p>Organizá tus proyectos, tareas y herramientas sin complicaciones.</p>
      <Link
        href="/dashboard"
        className="mt-6 inline-block bg-blue-600 text-white py-2 px-4 rounded"
      >
        Ir al panel
      </Link>
    </main>
  );
}